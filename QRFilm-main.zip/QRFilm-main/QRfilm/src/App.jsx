import { useState } from 'react';
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import './App.css'

function App() {
  const [movieText,setMovieText] = useState("");

  const navigate = useNavigate();

  const handleChangePage = ()=>{
    navigate("/video")
  }
  

  const handleGetAI = ()=>{

    axios.get("http://localhost:8000/").then((req)=>{
      console.log(req.data.content);
      setMovieText(req.data.content)
    })
  }
  return (
    <>
      <div>
        <button onClick={handleGetAI}>Hello</button>
        {movieText ? movieText:"No text"}
        <header className="header">
          <div className="container header_main">
            <img src="../images/horizontal_on_white_by_logaster 1.png" alt="logo" className="logo" />
            <ul className="nav">
              <li className="nav_item"><a href="#">Контакты</a></li>
              <li className="nav_item"><a href="#">О нас</a></li>
              <li className="nav_item"><a href="#">Контенту</a></li>
            </ul>
          </div>
          <div id="like_button_container" />
          <div className="container header_content">
            <h1 className="header_title">
              Фильмы, сериалы, короткометражки и многое от наших казахстанских издателей
            </h1>
            <p className="header_text">Смотрите во всех платфомах без подписки</p>
            <button className="btn" onClick={handleChangePage}>Кликайте и смотрите онлайн</button>
          </div>
        </header>
        <main>
          <section className="adaption">
            <div className="container">
              <div className="adaption_main">
                <div className="adaption_text">
                  <h2>Смотрите на смартфонах и в планшетах</h2>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur tempora rerum nam maiores
                    dolorem
                    reiciendis laboriosam magni excepturi recusandae consequuntur?</p>
                </div>
                <img src="../images/Group1.png" alt="foto" />
              </div>
            </div>
          </section>
          <section className="platform">
            <div className="container">
              <div className="platform_main">
                <div className="platform_text">
                  <h2>Доступно на ваших смарт ТВ</h2>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur tempora rerum nam maiores
                    dolorem
                    reiciendis laboriosam magni excepturi recusandae consequuntur?</p>
                </div>
                <img src="../images/Group2.png" alt="foto" />
              </div>
            </div>
          </section>
        </main>
        <footer>
          <div className="container">
            <div className="footer_main">
              <p>Задавайте свои вопросы</p>
              <div className="footer_bottom">
                <p>Наши контакты: +77772395194</p>
                <p>+708 365 80 49</p>
              </div>
              <p>kaisaratarku4@gmail.com</p>
            </div>
          </div>
        </footer>
      </div>

    </>
  )
}

export default App
