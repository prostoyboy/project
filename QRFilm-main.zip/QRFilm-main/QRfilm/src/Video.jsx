import "./App.css"
import { useNavigate } from "react-router-dom";

function Video() {
  const navigate = useNavigate();

  const handleChangePage = (myVideoParams)=>{

    // navigate(myVideoParams)
    console.log("Complete me")
  }
  return (
    <div>
        <div className="headerv">
          <div className="container">
            <div className="headerv_nav">
              <img src="../images/horizontal_on_white_by_logaster__1_-removebg-preview1.png" alt="logo" className="logo" />
              <div className="headerv_text">
                <a href="../index.html">Главная</a>
              </div>
            </div>
          </div>
        </div>
        <main className="allSeries">
          <div className="container">
            <div className="allSeries_text">
              <button  className="video allSeries_link" onClick={()=>handleChangePage("/video1")}>Человек паук</button>
              <button  className="video2 allSeries_link" onClick={()=>handleChangePage("/video2")}>Человек-паук 2</button>
            </div>
          </div>
        </main>
      </div>
    );
  }
;

export default Video
