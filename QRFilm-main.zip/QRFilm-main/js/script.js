$(document).ready(function () {

   let count = 0

   $('.comment_btn').on("click", function () {
      count++
      $('.comment_place').append(function (index) {
         return $('<p>', {
            text: 'Гость ' + count + ': ' + $(".comment_form").val() + ''
         })
      });
      $(".comment_form").val('')
   })

});


const domContainer = document.querySelector('#like_button_container');
const root = ReactDOM.createRoot(domContainer);
root.render(e(LikeButton));
const mysql = require("mysql2");
  
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  database: "usersdb",
  password: "пароль_от_сервера"
});
// тестирование подключения
 connection.connect(function(err){
    if (err) {
      return console.error("Ошибка: " + err.message);
    }
    else{
      console.log("Подключение к серверу MySQL успешно установлено");
    }
 });
 // закрытие подключения
 connection.end(function(err) {
  if (err) {
    return console.log("Ошибка: " + err.message);
  }
  console.log("Подключение закрыто");
});